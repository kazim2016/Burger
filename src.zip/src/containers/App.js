import React, { Component } from 'react';
import Layout from '../components/Layout/Layout';
import BurgerBuilder from '../containers/BurgerBiulder/BurgerBuilder';
import Aux from '../hoc/hoc';
import './App.css';

class App extends Component {
  render() {
    return (
      <Aux>
      <Layout>
        <BurgerBuilder/>
        </Layout>
        </Aux>
    );
  }
}

export default App;
