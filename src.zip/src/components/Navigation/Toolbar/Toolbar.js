import React from 'react';
import classes from './Toolbar.css';
import Logo from '../../Logo/Logo';
import Navigationitems from '../NavigationItems/NavigationItems';
import DrawerToggle  from '../Sidedrawer/DrawerToggle/DrawerToggle';


const Toolbar = (props) =>{
    return (
            <div className={classes.Toolbar}>
                <DrawerToggle clicked={props.drawerToggleClicked}/>
                <div>
                <Logo height="80%" />
                </div>
                <nav className={classes.DesktopOnly}>
                    <Navigationitems />
                </nav>
            </div>
           )
}

export default Toolbar;