import React, {Component} from 'react';
 import Aux from '../../hoc/hoc';
 import classes from '../Layout/Layout.css';
 import Toolbar from '../Navigation/Toolbar/Toolbar';
 import Sidedrawer from '../Navigation/Sidedrawer/SideDrawer'; 

class Layout extends Component {

    state = {
        showSideDrawer: false
    }

    sideDrawerClosedHandler = () => {
        this.setState({showSideDrawer: false });
    }

    sidedrawerToggleHandler = () => {
        this.setState((prevState) => {  
           return  {showSideDrawer: !prevState.showSideDrawer}; 
        });
    }


    render(){
        return (
                <Aux>
                    <Toolbar drawerToggleClicked={this.sidedrawerToggleHandler} /> 
                    <Sidedrawer 
                    open={this.state.showSideDrawer} 
                    closed={this.sideDrawerClosedHandler}/>
                    <br /><br />
                    <main className={classes.main}> 
                        {this.props.children}
                    </main>
            </Aux>
             )
    }
   
}


export default Layout;